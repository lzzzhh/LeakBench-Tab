# CDXR EDBT 2027 complete paper package

This bundle contains the complete current paper workspace: LaTeX sources,
bibliography, EDBT template, fonts and license, generated tables/macros,
figures in PDF/PNG/SVG/TIFF formats, paper-facing CSV assets, generation and
packaging scripts, the compiled PDF, and compact revision evidence tables.

The paper presents CDXR, a contract-grounded evaluation architecture that
separates construction validity, blind detectability, learner-conditional
exploitability, and matched-cost repair response. LeakBench-Tab is the
controlled experimental instantiation rather than the paper's sole claim.

Compile from this directory with:

```bash
tectonic -X compile main.tex --outdir output
```

The manuscript still contains placeholder author metadata. Replace the author,
affiliation, city, country, email, and ORCID fields before submission.

The included paper-facing assets are sufficient to compile the paper. Full
regeneration of evidence-derived assets requires the complete repository and
is intentionally not claimed to be standalone in this paper-only bundle.
